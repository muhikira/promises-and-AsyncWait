/*
*Lexical scope defines how variable names are resolved in nested functions;

*Nested (child) functions hae access to he scope of their parent functions;

*This is often confused with closure, but lexical scope is only an important part of closure.

*
*/

// Global scopes

// let x=1;

// const parentFunction = () => {
//     //local scope
//     let myValue = 2;
//     console.log(x);
//     console.log(myValue);

//     const childFunction=()=>{
//         console.log(x +=5);
//         console.log(myValue +=1);
//     }
//    childFunction();
// };
// parentFunction();
// console.log(x)


// LET MAKE IT  A CLOSURE

// let x=1;

// const parentFunction = () => {
//     let myValue = 2;
//     console.log(x);
//     console.log(myValue);

//     const childFunction=()=>{
//         console.log(x +=5);
//         console.log(myValue +=1);
//     }
//     return childFunction;
// };
// const result = parentFunction();
// console.log(result);
// result();
// result();
// result();

/*// the use of IIFE
const credits = ((number) => {
    let credits = number; console.log(`initial value:${credits}`);
    return () => {
        credits -= 1000;
        if (credits > 0) console.log(`paying bills,${credits} credits remaining in your account`);
        if (credits <= 0) console.log(`we are sorry you don't have enough credits in your account`)
    }
})(3000);// here we called IIFE

credits();
credits();
credits();
*/

// function reversed(string){
//     let reverse='';
//     for(let i=string.length-1;i>=0;i--){
//        let char=[i];
//        reverse+=char;
//     }
//     return reverse;
// }
// console.log(reversed("madam"));
// console.log(reversed("marathon"));

let reverseString= function(str){
    let reversed=" ";
    for(let i= str.length -1; i>=0; i--){
    let char=[i];

      reversed+=char;

    }
      return reversed;
    };

    console.log(reverseString('DOG')); // 'hsif'
    console.log(reverseString('marathon')); // 'nohtaram'
