let promise= new Promise((resolve,reject)=>{
    let a =1+4;
    if(a==2){
    resolve("Success")
    } else{
        reject("Failed")

    }
})

promise.then((message)=>{
    console.log('this is in them ' +message)
}).catch((message)=>{
    console.log('This is in catch ' +message)
})
