const recordVideoOne = new Promise((resolve, reject) =>{
    resolve('Video 1 Recorded')
})

const recordVideTwo = new Promise((resolve, reject) =>{
    resolve('Video 2 Recorded')
})

const recordVideoThree =  new Promise((resolve, reject) =>{
    resolve('Video 3 Recorded')
})
Promise.all([
    recordVideoOne,
    recordVideTwo,
    recordVideoThree,
]).then((message) =>{
    console.log(message)
})
